from langgraph.graph import StateGraph, END
from state import OnboardingState
from agents.orchestrator import orchestrator_agent
from agents.document_agent import document_agent
from agents.training_agent import training_agent
from agents.email_agent import email_agent
from agents.resume_parser import resume_parser_agent
from agents.screening_agent import screening_agent
from agents.scoring_agent import scoring_agent
from agents.decision_agent import decision_agent
from agents.communication_agent import communication_agent

def create_recruitment_graph():
    graph = StateGraph(OnboardingState)
    
    # Recruitment agents
    def run_resume_parser(state):
        result = resume_parser_agent(state['resume_path'])
        return {**state, "candidate_data": result, "employee_name": result['name'], "email": result['email']}
    
    def run_screening(state):
        result = screening_agent(state['candidate_data'], state['job_description'])
        return {**state, "screening_result": result}
    
    def run_scoring(state):
        result = scoring_agent(state['candidate_data'], state['screening_result'], state['job_description'])
        return {**state, "scoring_result": result}
    
    def run_decision(state):
        result = decision_agent(state['candidate_data'], state['scoring_result'], state['job_description'])
        return {**state, "decision_result": result}
    
    def run_communication(state):
        result = communication_agent(state['candidate_data'], state['decision_result'], state['job_description'])
        return {**state, "communication_result": result}
    
    # Onboarding agents — only run if HIRE decision
    def run_orchestrator(state):
        if state['decision_result']['decision'] == 'HIRE':
            return orchestrator_agent(state)
        return {**state, "current_step": "complete"}
    
    def run_document(state):
        if state['decision_result']['decision'] == 'HIRE':
            return document_agent(state)
        return state
    
    def run_training(state):
        if state['decision_result']['decision'] == 'HIRE':
            return training_agent(state)
        return state
    
    def run_email(state):
        if state['decision_result']['decision'] == 'HIRE':
            return email_agent(state)
        return state
    
    # Add nodes
    graph.add_node("resume_parser", run_resume_parser)
    graph.add_node("screening", run_screening)
    graph.add_node("scoring", run_scoring)
    graph.add_node("decision", run_decision)
    graph.add_node("communication", run_communication)
    graph.add_node("orchestrator", run_orchestrator)
    graph.add_node("document_agent", run_document)
    graph.add_node("training_agent", run_training)
    graph.add_node("email_agent", run_email)
    
    # Connect pipeline
    graph.set_entry_point("resume_parser")
    graph.add_edge("resume_parser", "screening")
    graph.add_edge("screening", "scoring")
    graph.add_edge("scoring", "decision")
    graph.add_edge("decision", "communication")
    graph.add_edge("communication", "orchestrator")
    graph.add_edge("orchestrator", "document_agent")
    graph.add_edge("document_agent", "training_agent")
    graph.add_edge("training_agent", "email_agent")
    graph.add_edge("email_agent", END)
    
    return graph.compile()

def process_candidate(resume_path: str, job_description: str, role: str, department: str, start_date: str):
    app = create_recruitment_graph()
    
    initial_state = {
        "employee_name": "",
        "role": role,
        "department": department,
        "start_date": start_date,
        "email": "",
        "documents_generated": [],
        "training_plan": "",
        "qa_context": "",
        "email_draft": "",
        "email_sent": False,
        "resume_path": resume_path,
        "job_description": job_description,
        "candidate_data": {},
        "screening_result": {},
        "scoring_result": {},
        "decision_result": {},
        "communication_result": {},
        "current_step": "resume_parser",
        "errors": []
    }
    
    print("\n" + "="*50)
    print("🚀 SMARTONBOARD — Starting Recruitment Pipeline")
    print("="*50)
    
    result = app.invoke(initial_state)
    
    print("\n" + "="*50)
    print("✅ PIPELINE COMPLETE")
    print("="*50)
    decision = result['decision_result'].get('decision', 'Unknown')
    score = result['scoring_result'].get('total_score', 0)
    print(f"Candidate: {result['employee_name']}")
    print(f"Score: {score}/100")
    print(f"Decision: {decision}")
    
    return result

if __name__ == "__main__":
    import sys
    resume = sys.argv[1] if len(sys.argv) > 1 else "/Users/krishnagarg/smartonboard/docs/KRISHNA GARG RESUME.pdf"
    
    jd = """
    We are looking for an AI/ML Engineer intern with:
    - Knowledge of Python and machine learning
    - Experience with deep learning frameworks like TensorFlow or PyTorch
    - Understanding of Computer Vision concepts
    - Experience building AI projects
    - Computer Science student or graduate
    - Strong problem solving skills
    """
    
    result = process_candidate(
        resume_path=resume,
        job_description=jd,
        role="Software Engineer",
        department="Engineering",
        start_date="June 15, 2026"
    )