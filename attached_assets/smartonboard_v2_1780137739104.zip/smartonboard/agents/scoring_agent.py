from dotenv import load_dotenv
import os
from langchain_groq import ChatGroq
from dotenv import load_dotenv
import os
import json

load_dotenv()

llm = ChatGroq(
    api_key=os.getenv("GROQ_API_KEY"),
    model_name="llama-3.3-70b-versatile"
)

def scoring_agent(candidate_data: dict, screening_result: dict, job_description: str) -> dict:
    print(f"\n📊 Scoring Agent: Scoring {candidate_data['name']}")
    
    result = llm.invoke(
        f"""You are an expert HR scoring system. Score this candidate objectively.
        
        CANDIDATE: {candidate_data['name']}
        Skills Match: {screening_result['skills_match_percentage']}%
        Experience Match: {screening_result['experience_match']}
        Education Match: {screening_result['education_match']}
        Matches: {screening_result['matches']}
        Gaps: {screening_result['gaps']}
        Screening Notes: {screening_result['screening_notes']}
        
        JOB DESCRIPTION: {job_description}
        
        Return ONLY a JSON object:
        {{
            "total_score": 0-100,
            "skills_score": 0-100,
            "experience_score": 0-100,
            "education_score": 0-100,
            "overall_fit": "Excellent/Good/Average/Poor",
            "strengths": ["strength1", "strength2"],
            "weaknesses": ["weakness1", "weakness2"],
            "scoring_reasoning": "3-4 sentence detailed reasoning"
        }}
        
        Return ONLY the JSON, no other text."""
    )
    
    try:
        content = result.content.strip()
        if "```" in content:
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
        parsed = json.loads(content)
    except:
        parsed = {
            "total_score": 0,
            "skills_score": 0,
            "experience_score": 0,
            "education_score": 0,
            "overall_fit": "Poor",
            "strengths": [],
            "weaknesses": [],
            "scoring_reasoning": "Could not parse scoring results"
        }
    
    print(f"✅ Scoring Agent: {parsed.get('total_score', 0)}/100 — {parsed.get('overall_fit', 'Unknown')}")
    return parsed