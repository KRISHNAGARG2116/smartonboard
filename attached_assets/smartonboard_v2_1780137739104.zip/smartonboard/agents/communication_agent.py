from dotenv import load_dotenv
import os
from langchain_groq import ChatGroq
from dotenv import load_dotenv
import os

load_dotenv()

llm = ChatGroq(
    api_key=os.getenv("GROQ_API_KEY"),
    model_name="llama-3.3-70b-versatile"
)

def communication_agent(candidate_data: dict, decision_result: dict, job_description: str) -> dict:
    print(f"\n✉️ Communication Agent: Drafting email for {candidate_data['name']}")
    
    decision = decision_result['decision']
    
    if decision == "HIRE":
        prompt = f"""Write a warm, professional offer email to {candidate_data['name']} 
        for the position they applied for.
        Include: congratulations, next steps, start date discussion, excitement about them joining.
        Sign off as 'The HR Team'"""
        
    elif decision == "INTERVIEW":
        prompt = f"""Write a professional interview invitation email to {candidate_data['name']}.
        Include: they've been shortlisted, interview details placeholder, what to prepare.
        Suggested interview questions to prepare for: {decision_result['suggested_interview_questions']}
        Sign off as 'The HR Team'"""
        
    else:
        prompt = f"""Write a kind, professional rejection email to {candidate_data['name']}.
        Include: thank them for applying, encourage them to apply for future roles.
        Do NOT mention specific reasons for rejection.
        Sign off as 'The HR Team'"""
    
    result = llm.invoke(prompt)
    
    print(f"✅ Communication Agent: {decision} email drafted")
    
    return {
        "email_type": decision,
        "email_content": result.content,
        "recipient": candidate_data.get('email', 'Unknown')
    }