from dotenv import load_dotenv
import os
from langchain_groq import ChatGroq
from langchain_community.document_loaders import PyPDFLoader
from dotenv import load_dotenv
import os
import json

load_dotenv()

llm = ChatGroq(api_key=os.getenv("GROQ_API_KEY"), model_name="llama-3.3-70b-versatile")

def resume_parser_agent(resume_path: str) -> dict:
    print(f"\n📄 Resume Parser: Reading {resume_path}")
    
    loader = PyPDFLoader(resume_path)
    pages = loader.load()
    resume_text = "\n".join([page.page_content for page in pages])
    
    result = llm.invoke(
        f"""Extract information from this resume and return ONLY a JSON object with these exact keys:
        {{
            "name": "full name",
            "email": "email address",
            "phone": "phone number",
            "skills": ["skill1", "skill2"],
            "experience_years": 0,
            "education": "highest degree and institution",
            "previous_roles": ["role1", "role2"],
            "summary": "2 sentence professional summary"
        }}
        
        Resume text:
        {resume_text}
        
        Return ONLY the JSON, no other text."""
    )
    
    try:
        content = result.content.strip()
        if "```" in content:
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
        parsed = json.loads(content)
    except:
        parsed = {
            "name": "Unknown",
            "email": "Unknown",
            "phone": "Unknown",
            "skills": [],
            "experience_years": 0,
            "education": "Unknown",
            "previous_roles": [],
            "summary": resume_text[:200]
        }
    
    print(f"✅ Resume Parser: Extracted data for {parsed.get('name', 'Unknown')}")
    return parsed