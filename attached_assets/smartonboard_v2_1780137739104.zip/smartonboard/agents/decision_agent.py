from dotenv import load_dotenv
import os
from langchain_groq import ChatGroq
from dotenv import load_dotenv
import os
import json

load_dotenv()

llm = ChatGroq(
    api_key=os.getenv("GROQ_API_KEY"),
    model_name="llama-3.3-70b-versatile"
)

def decision_agent(candidate_data: dict, scoring_result: dict, job_description: str) -> dict:
    print(f"\n✅ Decision Agent: Making decision for {candidate_data['name']}")
    
    result = llm.invoke(
        f"""You are a senior HR decision maker. Make a final hiring decision.
        
        CANDIDATE: {candidate_data['name']}
        Total Score: {scoring_result['total_score']}/100
        Overall Fit: {scoring_result['overall_fit']}
        Strengths: {scoring_result['strengths']}
        Weaknesses: {scoring_result['weaknesses']}
        Reasoning: {scoring_result['scoring_reasoning']}
        
        JOB DESCRIPTION: {job_description}
        
        Return ONLY a JSON object:
        {{
            "decision": "HIRE or INTERVIEW or REJECT",
            "confidence": "High/Medium/Low",
            "decision_reasoning": "3-4 sentence explanation",
            "suggested_interview_questions": ["question1", "question2", "question3"],
            "salary_recommendation": "salary range suggestion",
            "flag_for_human_review": true or false,
            "flag_reason": "reason if flagged"
        }}
        
        Rules:
        - Score 80+ = HIRE
        - Score 60-79 = INTERVIEW  
        - Score below 60 = REJECT
        - Always flag borderline cases (55-65) for human review
        
        Return ONLY the JSON, no other text."""
    )
    
    try:
        content = result.content.strip()
        if "```" in content:
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
        parsed = json.loads(content)
    except:
        parsed = {
            "decision": "INTERVIEW",
            "confidence": "Low",
            "decision_reasoning": "Could not parse decision",
            "suggested_interview_questions": [],
            "salary_recommendation": "To be determined",
            "flag_for_human_review": True,
            "flag_reason": "Parsing error — manual review required"
        }
    
    print(f"✅ Decision Agent: {parsed.get('decision')} — {parsed.get('confidence')} confidence")
    return parsed