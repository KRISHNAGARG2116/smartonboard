from dotenv import load_dotenv
import os
from langchain_groq import ChatGroq
from dotenv import load_dotenv
import os
import json

load_dotenv()

llm = ChatGroq(
    api_key=os.getenv("GROQ_API_KEY"),
    model_name="llama-3.3-70b-versatile"
)

def screening_agent(candidate_data: dict, job_description: str) -> dict:
    print(f"\n⚖️ Screening Agent: Checking {candidate_data['name']} against JD")
    
    result = llm.invoke(
        f"""You are an expert HR screener. Compare this candidate against the job description.
        
        CANDIDATE:
        Name: {candidate_data['name']}
        Skills: {candidate_data['skills']}
        Experience: {candidate_data['experience_years']} years
        Education: {candidate_data['education']}
        Previous Roles: {candidate_data['previous_roles']}
        Summary: {candidate_data['summary']}
        
        JOB DESCRIPTION:
        {job_description}
        
        Return ONLY a JSON object:
        {{
            "matches": ["requirement1 that candidate meets"],
            "gaps": ["requirement1 that candidate is missing"],
            "experience_match": true or false,
            "education_match": true or false,
            "skills_match_percentage": 0-100,
            "screening_notes": "2-3 sentence assessment"
        }}
        
        Return ONLY the JSON, no other text."""
    )
    
    try:
        content = result.content.strip()
        if "```" in content:
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
        parsed = json.loads(content)
    except:
        parsed = {
            "matches": [],
            "gaps": [],
            "experience_match": False,
            "education_match": False,
            "skills_match_percentage": 0,
            "screening_notes": "Could not parse screening results"
        }
    
    print(f"✅ Screening Agent: {parsed.get('skills_match_percentage', 0)}% skills match")
    return parsed