from typing import TypedDict, List, Optional

class OnboardingState(TypedDict):
    # Employee info
    employee_name: str
    role: str
    department: str
    start_date: str
    email: str
    
    # Agent outputs — filled as agents complete their work
    documents_generated: List[str]
    training_plan: str
    qa_context: str
    email_draft: str
    email_sent: bool
    
    # Tracking
    current_step: str
    errors: List[str]